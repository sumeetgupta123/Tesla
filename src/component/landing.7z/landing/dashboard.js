import React, { Component } from 'react'
import tag from '../../assets/about.png'
export default class dashboard extends Component {
    constructor(props) {
        super(props)

        this.state = {
            Insurance: [
                {
                    "additionalEligibility": "string",
                    "additionalFeatures": "string",
                    "createdOn": "2021-05-20T06:16:19.991Z",
                    "crop": "Rice",
                    "cropSeason": "string",
                    "id": 0,
                    "loanee": "string",
                    "lowerAge": "string",
                    "maximumFarmLandArea": "string",
                    "minimumFarmLandArea": "string",
                    "name": "pradhan Mantri Fasal Bima Yojna",
                    "policyTransfer": true,
                    "premiumRatesAndSubsidies": "string",
                    "reinsured": false,
                    "riskType": "string",
                    "sellerId": 0,
                    "status": true,
                    "upperAge": "string"
                },
                {
                    "additionalEligibility": "string",
                    "additionalFeatures": "string",
                    "createdOn": "2021-05-20T06:16:19.991Z",
                    "crop": "Paddy",
                    "cropSeason": "string",
                    "id": 1,
                    "loanee": "string",
                    "lowerAge": "string",
                    "maximumFarmLandArea": "string",
                    "minimumFarmLandArea": "string",
                    "name": "pradhan Mantri Fasal Bima Yojna",
                    "policyTransfer": true,
                    "premiumRatesAndSubsidies": "string",
                    "reinsured": true,
                    "riskType": "string",
                    "sellerId": 0,
                    "status": true,
                    "upperAge": "string"
                },
                {
                    "additionalEligibility": "string",
                    "additionalFeatures": "string",
                    "createdOn": "2021-05-20T06:16:19.991Z",
                    "crop": "Wheat",
                    "cropSeason": "string",
                    "id": 2,
                    "loanee": "string",
                    "lowerAge": "string",
                    "maximumFarmLandArea": "string",
                    "minimumFarmLandArea": "string",
                    "name": "pradhan Mantri Fasal Bima Yojna",
                    "policyTransfer": true,
                    "premiumRatesAndSubsidies": "string",
                    "reinsured": false,
                    "riskType": "string",
                    "sellerId": 0,
                    "status": true,
                    "upperAge": "string"
                },
                {
                    "additionalEligibility": "string",
                    "additionalFeatures": "string",
                    "createdOn": "2021-05-20T06:16:19.991Z",
                    "crop": "Oats",
                    "cropSeason": "string",
                    "id": 3,
                    "loanee": "string",
                    "lowerAge": "string",
                    "maximumFarmLandArea": "string",
                    "minimumFarmLandArea": "string",
                    "name": "pradhan Mantri Fasal Bima Yojna",
                    "policyTransfer": true,
                    "premiumRatesAndSubsidies": "string",
                    "reinsured": true,
                    "riskType": "string",
                    "sellerId": 0,
                    "status": true,
                    "upperAge": "string"
                },
                {
                    "additionalEligibility": "string",
                    "additionalFeatures": "string",
                    "createdOn": "2021-05-20T06:16:19.991Z",
                    "crop": "Barley",
                    "cropSeason": "string",
                    "id": 4,
                    "loanee": "string",
                    "lowerAge": "string",
                    "maximumFarmLandArea": "string",
                    "minimumFarmLandArea": "string",
                    "name": "pradhan Mantri Fasal Bima Yojna",
                    "policyTransfer": true,
                    "premiumRatesAndSubsidies": "string",
                    "reinsured": true,
                    "riskType": "string",
                    "sellerId": 0,
                    "status": true,
                    "upperAge": "string"
                }
                ,

            ]
        }
    }

    render() {
        return (
            <div>
                <div className="col-12 float-left top-card">
                    <p>Home / Dashboard</p>
                    <input type="text" placeholder="Search Insurance" className="Search-input" />
                    <button className="Search-btn">Search</button>
                </div>
                <div className="col-12 float-left">
                    <div className="col-12 help-card float-left">
                        <div className="col-8 float-left">
                            <h4>Need help picking Insurance</h4>
                            <p>Not Sure which Insurance is best for you, we are free to help you</p>
                        </div>
                        <div className="col-4 float-right">
                            <button className="Search-btn float-left my-3">Try our insurance finder</button>
                        </div>
                    </div>
                </div>
                <div className="col-12 float-left my-2 p-0">
                    {this.state.Insurance.map((item, i) => (<div key={item.id} className="col-4 float-left">
                        <div className="col-12 float-left detail-card">
                            <img src={tag} alt="logo" className="tag-img float-left"></img>
                            <p className="col-8 float-left ">{item.name}</p>
                            <p className="float-right">kharif</p>
                            <div className="col-12 float-left p-0">
                                <div className="col-6 float-left p-0">
                                    <label className="col-12 float-left">Crop Name</label>
                                    <span className="col-12 float-left details">{item.crop}</span>
                                </div>
                                <div className="col-6 float-left p-0">
                                    <label className="col-12 float-left">Reinsured</label>
                                    <span className="col-12 float-left details">{item.reinsured ? 'Yes' : 'No'}</span>
                                </div>

                            </div>
                            <div className="col-12 float-left p-0 centeralign my-3" >
                                <button className="read-btn">Read more</button>
                                </div>
                        </div>
                    </div>))}
                </div>
            </div>
        )
    }
}
