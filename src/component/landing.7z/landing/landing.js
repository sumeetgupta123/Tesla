import React, { Component } from 'react'
import Head from './head'
import Nav from './nav'
import Dashboard from './dashboard'
import Account from './account'
import './landing.css'
import { BrowserRouter as Router, Switch, Route,Redirect } from 'react-router-dom';

export default class landing extends Component {
    constructor(props) {
        super(props)

        this.state = {

        }
    }

    render() {
        return (
            <Router>
                <div>
                    <Head />
                    <Nav />
                    <Switch>
                    <Redirect exact from="/landing" to="/dashboard" />
                        <Route exact path="/dashboard" >
                            <div className="col-12 float-left container-dash">
                                <Dashboard />
                            </div>
                        </Route>
                        <Route exact path="/account" >
                            <div className="col-12 float-left container-dash">
                                <Account />
                            </div>
                        </Route>
                     
                    </Switch>
                </div>
            </Router>
        )
    }
}
